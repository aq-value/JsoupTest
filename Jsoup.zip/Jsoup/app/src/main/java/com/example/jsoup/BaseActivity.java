package com.example.jsoup;

import android.support.v7.app.AppCompatActivity;

class BaseActivity extends AppCompatActivity {
}
